<?php
define('STATIC_PATH',dirname(__FILE__));
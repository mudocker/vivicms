<br /><center>Powered by： vivi小偷程序后台管理系统</center>
<script>
    var onFocus=function(self){
        self.style.borderColor='#00CC00';
    }
    var onBlur=function (self) {
        self.style.borderColor='#dcdcdc'
    }
</script>
<style>
    .config7_input {
        width:300px;
    }

</style>
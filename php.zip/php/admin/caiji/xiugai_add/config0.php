<tbody>
<tr nowrap class="tb_head">
    <td colspan="2"><div style='float:left;padding:5px;'>采集节点设置：</div>&nbsp;&nbsp;<div style='float:left;padding:5px;border:1px dotted #ff6600;background:#ffffee'>过滤替换规则是在程序处理之后执行，请按照采集后的页面源代码进行编写，不是目标站原始源代码，保存后打开<font color="red">本站前台</font>页面查看源代码</div></td>
</tr>
<tr class="firstalt">
    <td colspan="2">
        <ul class="do_nav">
            <li id="tab1" class="cur"><a onclick="tab(1,6);" href="javascript:">基本设置</a></li>
            <li id="tab2"><a onclick="tab(2,6);" href="javascript:">替换过滤</a></li>
            <li id="tab3"><a onclick="tab(3,6);" href="javascript:">自定义标签</a></li>
            <li id="tab4"><a onclick="tab(4,6);" href="javascript:">自定义css</a></li>
            <li id="tab5"><a onclick="tab(5,6);" href="javascript:">高级功能</a><img src="public_admin/img/vip.gif" style="cursor: pointer;vertical-align: middle;" title="vip功能" width="19" height="18" /></li>
            <li id="tab6"><a onclick="tab(6,6);" href="javascript:">破防采集</a><img src="public_admin/img/vip.gif" style="cursor: pointer;vertical-align: middle;" title="vip功能" width="19" height="18" /></li>
            <li id="tab6"><a onclick="tab(7,6);" href="javascript:">资源站配置</a><img src="public_admin/img/vip.gif" style="cursor: pointer;vertical-align: middle;" title="vip功能" width="19" height="18" /></li>
        </ul>
    </td>
</tr>
</tbody>
         
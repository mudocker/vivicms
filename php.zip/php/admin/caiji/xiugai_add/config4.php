<tbody id="config4" style="display:none">
<tr nowrap class="firstalt">
    <td width="260" valign='top'><b>自定义css</b><br>
        <font color="#666666">css代码，一行一个，格式如下：<br><div style='padding:5px;border:1px dotted #ff6600;background:#f6f6f6'><font color="red">.a{color:red}</font></div>提示：{webpath}表示根路径</font></td>
    <td><textarea name="con[css]" style="height: 100px; width: 550px" onFocus="this.style.borderColor='#00CC00'" onBlur="this.style.borderColor='#dcdcdc'" ><?php echo _htmlspecialchars($caiji_config['css']);
            ?></textarea></td>
</tr>
</tbody>
<tbody>
    <tr class="firstalt">
        <td align="center" colspan="2">
            <input type="submit" value=" 提交 " name="submit" class="bginput">&nbsp;&nbsp;
            <input type="button" onclick="history.go(-1);" value=" 返回 " name="Input" class="bginput">
        </td>
    </tr>
</tbody>
<?php

use md\inc\caiji;

if($ac == 'yulan'){
   $caiji= new caiji();
    require(VV_DATA . '/rules.php');
    exit;
}
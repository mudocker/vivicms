<?php

define('SCRIPT','search');
require(dirname(__FILE__)."/inc/common.inc.php");
$v_config=require(VV_DATA."/config.php");


require(dirname(__FILE__)."/inc/caiji.class.php");
require(dirname(__FILE__)."/inc/robot.php");
require("rules.php");
?>
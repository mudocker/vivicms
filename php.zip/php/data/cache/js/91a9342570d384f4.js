(function() {

	var pcurl = window.location.href,
		pathname = window.location.pathname;

	var ARTICLE_ID = pathname.replace(/(\/|a|.htm)|(_\w+).htm|/ig,'');
	var quyuArr = ['house.qq.com', 'ly.qq.com', 'city.qq.com'],
		currSite = '';

	// sy\nj\yichang ����\�Ͼ�\�˲� ���ڴ���Ƶ��
	var cityArr = {'house': 'house', 'bj': 'beijing', 'jm': 'jiangmen','news': 'news','sg': 'shaoguan','zs': 'zhongshan','cd': 'chengdu','cs': 'changsha','cq': 'chongqing','dg': 'dongguan','fs': 'foshan','fz': 'fuzhou','gz': 'guangzhou','hz':'hangzhou','huizhou': 'huizhou','qy': 'qingyuan','sz': 'shenzhen','sh': 'shanghai','wh': 'wuhan','xm': 'xiamen','xian': 'xian','zh': 'zhuhai','zz': 'zhenzhou'};
	var currCity = cityArr[pcurl.split('/')[2].split('.')[0]];


	for( var i = quyuArr.length - 1; i >= 0; i--) {
		if(new RegExp(quyuArr[i]).test(pcurl)) {
			currSite = quyuArr[i]; break;
		}
	}

	function reWriteUrl() {
		var surl = 'http://' + window.location.hostname + window.location.pathname + '?newspc';
		return 'http://m.'+ currSite + '/a/' + ARTICLE_ID + '/?rf=pcarticle&surl=' + encodeURIComponent(surl);
	}

	function reNewsWriteUrl(url) {

		var Splits = url.split("/"),siteName=Splits[2].split("qq.com")[0].split(".").length==3?siteName=Splits[2].split("qq.com")[0].split(".")[0]+"_"+Splits[2].split("qq.com")[0].split(".")[1]:siteName=Splits[2].split("qq.com")[0].split(".")[0],aids=url.split("/a/")[1].split(".htm")[0].replace(/[^0-9]/g, ""),site="";
		
		if(typeof siteName !=="undefined" && typeof aids!=="undefined"){
			if(siteName.split(".").length>2){
				var len = siteName.split(".").length;
				for(var i=0;i<len;i++){
						site+=siteName.split(".")[i];
						if(i<len-2){
							site+="_";
						}
				}
			}else{
				site=siteName.split(".")[0];
			}
			return "http://xw.qq.com/"+siteName+"/"+aids;
		}
	};

	function sendBoss(sOp) {
		var sRef = sRef || '';
		var sUrl = encodeURIComponent(window.location.href);
		var g_btrace_BOSS = new Image(1,1);
		g_btrace_BOSS.src = "http://btrace.qq.com/kvcollect?BossId=3355&Pwd=1959290082&sEvent="+ ARTICLE_ID +"&sOp="+ sOp + "&iFromtype=5&sUrl="+ sUrl +"&sRef="+ sRef +"&_dc=" + Math.random();
	}

	
	// �ƶ��ˡ���������
	if(/Android|webOS|iPhone|Windows Phone|iPod|BlackBerry|SymbianOS/i.test(navigator.userAgent) && currSite ) {
		
		if(pcurl.indexOf("/a/") > 0) {
			if(pcurl.indexOf("?newspc") > 0) {
				// �����Ĵ���
				if(/house.qq.com/.test(window.location.host) && currCity) {
					// ��������Ƶ�� - Ĭ������ҳ
					sendBoss('article_source_xw');
					window.location.href = reNewsWriteUrl(pcurl);
					return;
				}
			} else if(pcurl.indexOf("njtm") < 0 && pcurl.indexOf("?pc") < 0) {
				// pc ������ת
				sendBoss('article_'+quyuArr[i].split('.')[0]);
				window.location.href = reWriteUrl(pathname);
				return;
			}
		} else if (pcurl.indexOf("?mobile") < 0 && /house.qq.com/.test(window.location.host) ) {
			sendBoss('article_source_xw');
			window.location.href = "http://xw.qq.com/m/house/index.htm";
			return;
		}
		sendBoss('article_source_pc');
	}

})();/*  |xGv00|9c4b05d0f20971c6d8c0ce5fc8f6a92b */
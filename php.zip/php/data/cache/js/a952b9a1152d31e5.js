//管家关键词下线

// 浏览器IE8一下升级tips
if(typeof $ === 'function'){
  $.getScript('//stdl.qq.com/stdl/qqbrowser/floatlayer/ie-remind-top-banner.js', function(){
    $.qbRecommand({ title: '腾讯网', minVersion:9});
  })
}/*  |xGv00|0d02e757f74fb717892b1324dea31f80 */
<?php

namespace md\data;
class downOther
{

    /**
     * downOther constructor.
     */
    public function __construct()
    {

    }
}
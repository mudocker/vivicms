<?php

namespace md\data\flow;
use md\data\BaseGlobal;

class getHtmlCode extends BaseGlobal {
     function __construct($caiji){
        new getHtml($caiji);

    }






}

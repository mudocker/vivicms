<?php
namespace md\data\rules;
use md\data\BaseCaijiConfig;
use md\data\BaseGlobal;


class getImgDomain  extends BaseCaijiConfig {
     function __construct()
    {
       // $this->resdomain = $this->resdomain?$this->resdomain:$this->other_imgurl;
    }



}



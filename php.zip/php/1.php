<?php
require './vendor/autoload.php';
phpinfo();
<?php
require_once(dirname(dirname(__FILE__)).'/inc/common.inc.php');

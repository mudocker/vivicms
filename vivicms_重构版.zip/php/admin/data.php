<?php
$adminname="ybetadmin";
$password="a57239961fe56ab2fa36b6b4ad04f7d4";
?>
<?php
if($ac == 'yulan'){
    require(VV_INC . "/caiji.class.php");
    require(VV_DATA . '/rules.php');
    exit;
}
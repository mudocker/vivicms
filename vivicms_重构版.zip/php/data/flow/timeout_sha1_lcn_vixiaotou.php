<?php
$cache=($v_config['cacheon'] || $caiji_config['collect_close']);
$timeout=checktime_log_out_1h();
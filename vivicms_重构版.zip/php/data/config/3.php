<?php
return array (
  'name' => 'ater',
  'from_title' => 'ater',
  'from_url' => 'http://www.ater.cn',
  'charset' => 'utf-8',
  'other_url' => '',
  'resdomain' => '',
  'img_delay_name' => '',
  'search_url' => '',
  'search_charset' => 'gb2312',
  'hidejserror' => '0',
  'no_siteapp' => '0',
  'licence' => '',
  'body_start' => '',
  'body_end' => '',
  'replacerules' => '/----------------文字替换（本行格式为注释,仅用于方便查看,下同）----------------/
##########
这里可以写替换规则
##########
/----------------图片替换----------------/
##########
这里可以写替换规则
##########
/----------------广告替换----------------/
##########
这里可以写替换规则
##########
/----------------其他替换----------------/
##########
这里可以写替换规则
##########',
  'siftrules' => '',
  'replace_before_on' => '0',
  'replacerules_before' => '',
  'siftrules_before' => '',
  'css' => '',
  'big52gbk' => '0',
  'replace' => '0',
  'rewrite' => '1',
  'tplfile' => '',
  'cookie' => '',
  'user_agent' => '',
  'referer' => '',
  'ip' => '',
  'ip_type' => '1',
  'zdy' => 
  array (
    0 => 
    array (
      'type' => '0',
      'body' => '',
      'regx' => '',
      'start' => '',
      'end' => '',
    ),
  ),
  'plus' => '',
  'siftags' => 
  array (
    0 => 'iframe',
    1 => 'object',
  ),
  'time' => 1534757203,
);
?>
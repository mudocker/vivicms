<?php
return array (
  'name' => '菜刀客',
  'from_title' => '菜刀客',
  'from_url' => 'http://www.caidaoke.com/',
  'charset' => 'utf-8',
  'other_url' => 'caidaoke.com',
  'resdomain' => '',
  'img_delay_name' => '',
  'search_url' => '',
  'search_charset' => 'gb2312',
  'hidejserror' => '0',
  'no_siteapp' => '0',
  'licence' => '',
  'body_start' => '',
  'body_end' => '',
  'replacerules' => '',
  'siftrules' => '',
  'replace_before_on' => '0',
  'replacerules_before' => '',
  'siftrules_before' => '',
  'css' => '',
  'big52gbk' => '0',
  'replace' => '0',
  'rewrite' => '0',
  'tplfile' => '',
  'cookie' => '',
  'user_agent' => '',
  'referer' => '',
  'ip' => '',
  'ip_type' => '1',
  'zdy' => 
  array (
    0 => 
    array (
      'type' => '0',
      'body' => '',
      'regx' => '',
      'start' => '',
      'end' => '',
    ),
  ),
  'plus' => '',
  'siftags' => 
  array (
    0 => 'iframe',
    1 => 'object',
  ),
  'time' => 1533200280,
);
?>
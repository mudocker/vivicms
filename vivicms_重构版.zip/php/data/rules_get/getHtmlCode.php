<?php

require_once(VV_DATA . '/flow/timeout_sha1_lcn_vixiaotou.php');
$cache && $timeout?  require_once (DRGET.'core.php'): $isgetnew =  getHtml($caiji);










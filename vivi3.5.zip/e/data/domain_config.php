<?php
return array (
  'temp2.cm' => 1,
);
?>
<?php
require_once('data.php');
require_once('checkAdmin.php');
require_once('../inc/common.inc.php');;
echo '<div class="right_top"><marquee behavior=slide width=600 scrollamount=10 onmouseover=this.stop() onmouseout=this.start()>';
echo $var_98;
echo '</marquee></div>';

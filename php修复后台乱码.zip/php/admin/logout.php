<?php
/**
 * --------------------------
 * viviС͵��վϵͳ
 * qq:996948519
 * ---------------------------
 */
setcookie("x_Cookie", "");
setcookie("y_Cookie", "");
echo "<script>location.href='index.php';</script>";
exit;
?>
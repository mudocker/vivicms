<?php
/**
 * --------------------------
 * vivi小偷网站系统
 * qq:996948519
 * ---------------------------
 */
require_once('data.php');
require_once('checkAdmin.php');
?>
<html>
<head>
<title>小偷后台管理系统 管理面版 v</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
</head>
<body text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td background="../public/img/top7.gif"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="600"><img src="../public/img/top6.gif" width="600" height="90"></td>
          <td valign="top"><a href="../" target="_blank"><img src="../public/img/top20.gif" width="70" height="63" border="0"></a>
		  <a href="http://www.vxiaotou.com" target="_blank"><img src="../public/img/top21.gif" width="70" height="63" border="0"></a>
		  <a href="update.php?t=update" target="content"><img src="../public/img/top22.gif" width="70" height="63" border="0"></a>
		  <a href="http://www.vxiaotou.com/plugin.php?id=vivi_accr:accr" target="_blank"><img src="../public/img/top24.gif" width="70" height="63" border="0"></a>
		  <a href="logout.php" onClick="return confirm('确定退出?')" target="_top"><img src="../public/img/top23.gif" width="70" height="63" border="0"></a>
		 </td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>
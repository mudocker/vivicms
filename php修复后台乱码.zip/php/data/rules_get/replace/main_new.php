<?php
if($isgetnew && $GLOBALS['html']){

    require_once (DREPLACE.'plug_before_convert_charset.php');
    require_once (DREPLACE.'html_gbk_utf8.php');
    require_once (DREPLACE.'replace_before_on.php');
    require_once (DREPLACE.'meta_content_frame.php');
    require_once (DREPLACE.'other_url.php');
    require_once (DREPLACE.'match_res.php');
    require_once (DREPLACE.'pic.php');
    require_once (DREPLACE.'js.php');
    require_once (DREPLACE.'css.php');
    require_once (DREPLACE.'href.php');
    require_once (DREPLACE.'gbk.php');
    require_once (VV_DATA.'/flow/isNewCache.php');

}

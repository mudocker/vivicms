<?php

    require_once (DREPLACE.'main_new.php');
  require_once (DREPLACE.'from_title.php');
    require_once (DREPLACE.'search_url.php');
    require_once (DREPLACE.'replace_zdy.php');
    require_once (DREPLACE.'zdy.php');
    require_once (DREPLACE.'config_ads2.php');
    require_once (DREPLACE.'no_css_js.php');
    require_once (DRGET.'linkword_on.php');
    plus_run('end');

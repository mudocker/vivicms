<?php
define('VV_PLUS', true);
$GLOBALS['isplus'] = false;
plus_run('init');
plus_run('before_get');

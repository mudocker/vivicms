<?php
$caiji_config['resdomain'] = $caiji_config['resdomain']?$caiji_config['resdomain']:$caiji_config['other_imgurl'];